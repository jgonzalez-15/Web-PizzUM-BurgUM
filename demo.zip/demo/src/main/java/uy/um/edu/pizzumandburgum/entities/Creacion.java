package uy.um.edu.pizzumandburgum.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Creacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id_creacion;

    public Creacion(){}

    public Creacion(long id_creacion) {
        this.id_creacion = id_creacion;
    }

}
